function GetURLParameter(sParam) {
    var sPageURL = window.location.search.substring(1);
	
	
    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++) {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam) {
            return sParameterName[1];
        }
    }
}

function applyRedTheme() {
	var head = document.getElementsByTagName('head')[0];
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = 'http://dv1mwap01:7777/common/2.0.5.1/css/layout-dt.min.css';
    link.media = 'all';
    head.appendChild(link);
}

function applyRedThemeToMenu() {
	$("a").css('background-color','#C62926');
	$("a").css('color','#ffffff');
	$("b").css('color','#ffffff');
	$("li").css('background-color','#ffffff');
	$("i").css('background-color','#C62926');
}

$(function(){
	if ((GetURLParameter('theme') == 'red')) {
		var url = window.location.toString();
	
		if(url.indexOf("menu.html") == -1){
			applyRedTheme();
		}else{
			applyRedThemeToMenu();
		}
        
		$("[href='menu.html']").attr('href','menu.html?theme=red');
		$("[href='SimpleForm.html']").attr('href','SimpleForm.html?theme=red');
		$("[href='SimpleFormWithTable.html']").attr('href','SimpleFormWithTable.html?theme=red');
		$("[href='FormWithTableEdit.html']").attr('href','FormWithTableEdit.html?theme=red');
		$("[href='SimpleView.html']").attr('href','SimpleView.html?theme=red');
		$("[href='SimpleViewWithTable.html']").attr('href','SimpleViewWithTable.html?theme=red');
		$("[href='SimpleViewWithTabs.html']").attr('href','SimpleViewWithTabs.html?theme=red');
		$("[href='SearchResults.html']").attr('href','SearchResults.html?theme=red');
		$("[href='Wizard.html']").attr('href','Wizard.html?theme=red');
		$("[href='Error.html']").attr('href','Error.html?theme=red');
    }
	
});

